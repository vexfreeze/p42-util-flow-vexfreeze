WELCOME! This widget was created by a //42 Flow PRO user. Pro is a platform for power users. With Pro and basic JavaScript knowledge, you can create custom widgets and share them! Want to learn more?

Check out http://www.parallel42.com/helloflow

DISCLAIMER: You are using user-created content. Parallel 42 is not responsible for distributing or maintaining this widget. Please install at your own risk and practice common sense when vetting the source.

INSTALLATION:

0: QUIT MSFS 2020.

1: Locate your Microsoft Flight Simulator COMMUNITY folder. All user-created content is executed from this directory.

Microsoft Store Version
C:\Users\USERNAME\AppData\Local\Packages\Microsoft.FlightSimulator_RANDOM\LocalCache\Packages\Community 

Steam Version 
C:\Users\USERNAME\AppData\Roaming\Microsoft Flight Simulator\Packages\Community

Not found?
The Community folder may also be located in: 
C:\Users\USERNAME\AppData\Roaming\Microsoft Flight Simulator\Packages\Community

STILL NOT FOUND?
At this point, you may want to reconsider installing 3rd party created content. Finding where to place it is an essential requirement for running mods.


2: Extract the contents of this downloaded widget or wheel into your Community folder.

3: Load into your sim, open Flow, and you'll find imported content in the COMMUNITY directory within the Editor mode.
